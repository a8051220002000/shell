#!/bin/bash
 
# Defined Color
Red='\033[31m\033[1m'
Green='\033[32m\033[1m'
Null='\033[0m'
 
ipsetconf=/etc/sysconfig/ipset_twlist

useipset=$(ipset list twblocks|wc -l)

if [ ${useipset} -eq 0 ];then
    ipset restore -f ${ipsetconf}
fi

systemctl restart iptables

echo -e "${Green}Done${Null}"
