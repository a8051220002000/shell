#!/bin/bash

rm -rf tw.zone
wget http://www.ipdeny.com/ipblocks/data/countries/tw.zone 

ipsetconf=/etc/sysconfig/ipset_twlist

ipset destroy twblocks
ipset create  twblocks hash:net
for i in $(cat tw.zone ); do ipset -A twblocks $i; done
ipset save -f ${ipsetconf}


#ipset list twblocks
