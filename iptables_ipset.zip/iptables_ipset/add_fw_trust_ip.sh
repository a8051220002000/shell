#!/bin/bash

read -p "Give me an IP..." IP
while [ 1 ]
do echo "$IP" | egrep -q '^([0-9]{1,3}\.){3}[0-9]{1,3}$'
 if [ $? -eq 0 ]
 then valid=1
 for number in ${IP//./ }
 do if [ $number -gt 255 ]
 then valid=0
 break
 fi
 done
 if [ $valid -eq 1 ]
 then break
 fi
 fi
 read -p "Incorrect format, please input again..." IP
done

iptables -I INPUT 4 -m tcp -s $IP   -p tcp -m multiport --dports 80,443,8068 -j ACCEPT
iptables-save > /etc/sysconfig/iptables
